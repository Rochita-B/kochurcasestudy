package com.cg.pizza.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.pizza.beans.Orders;

public interface PizzaDAO extends JpaRepository<Orders, Integer>{

}
