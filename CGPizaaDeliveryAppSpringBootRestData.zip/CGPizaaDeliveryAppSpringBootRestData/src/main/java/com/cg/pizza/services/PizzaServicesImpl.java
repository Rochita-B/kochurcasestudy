package com.cg.pizza.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizza.beans.Orders;
import com.cg.pizza.daoservices.PizzaDAO;
import com.cg.pizza.exceptions.OrderDetailsIncorrectException;

@Component("pizzaServices")
public class PizzaServicesImpl implements PizzaServices{
	@Autowired
	PizzaDAO pizzaDao;
	
	@Override
	public Orders acceptOrderDetails(Orders order) {		
		return pizzaDao.save(order);
	}

	@Override
	public Orders getOrderDetails(int orderId) throws OrderDetailsIncorrectException {		
		return pizzaDao.findById(orderId).orElseThrow(()->new OrderDetailsIncorrectException("Your order is not available"));
	}

	@Override
	public List<Orders> getAllOrderDetails() {		
		return pizzaDao.findAll();
	}

	@Override
	public boolean cancelOrderDetails(int orderId) throws OrderDetailsIncorrectException {
		pizzaDao.delete(getOrderDetails(orderId));
		return true;
	}

}
