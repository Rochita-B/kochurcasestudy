package com.cg.pizza.services;

import java.util.List;

import com.cg.pizza.beans.Orders;
import com.cg.pizza.exceptions.OrderDetailsIncorrectException;

public interface PizzaServices {
	Orders acceptOrderDetails(Orders order);
	Orders getOrderDetails(int orderId) throws OrderDetailsIncorrectException;
	List<Orders>getAllOrderDetails();
	boolean cancelOrderDetails(int orderId) throws OrderDetailsIncorrectException;
}
