package com.cg.pizza.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Pizza {
private String pizzaType;
private String pizzaSize;
public Pizza() {}
public Pizza(String pizzaType, String pizzaSize) {
	super();
	this.pizzaType = pizzaType;
	this.pizzaSize = pizzaSize;
}
public String getPizzaType() {
	return pizzaType;
}
public void setPizzaType(String pizzaType) {
	this.pizzaType = pizzaType;
}
public String getPizzaSize() {
	return pizzaSize;
}
public void setPizzaSize(String pizzaSize) {
	this.pizzaSize = pizzaSize;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((pizzaSize == null) ? 0 : pizzaSize.hashCode());
	result = prime * result + ((pizzaType == null) ? 0 : pizzaType.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Pizza other = (Pizza) obj;
	if (pizzaSize == null) {
		if (other.pizzaSize != null)
			return false;
	} else if (!pizzaSize.equals(other.pizzaSize))
		return false;
	if (pizzaType == null) {
		if (other.pizzaType != null)
			return false;
	} else if (!pizzaType.equals(other.pizzaType))
		return false;
	return true;
}
@Override
public String toString() {
	return "Pizza [pizzaType=" + pizzaType + ", pizzaSize=" + pizzaSize + "]";
}

}
