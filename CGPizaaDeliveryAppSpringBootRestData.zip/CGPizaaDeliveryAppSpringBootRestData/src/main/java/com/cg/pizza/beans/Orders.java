package com.cg.pizza.beans;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Orders {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int orderId;
private String orderType;
private String orderDate;
@Embedded
private Pizza pizza;
public Orders() {}
public Orders(int orderId, String orderType, String orderDate, Pizza pizza) {
	super();
	this.orderId = orderId;
	this.orderType = orderType;
	this.orderDate = orderDate;
	this.pizza = pizza;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public String getOrderType() {
	return orderType;
}
public void setOrderType(String orderType) {
	this.orderType = orderType;
}
public String getOrderDate() {
	return orderDate;
}
public void setOrderDate(String orderDate) {
	this.orderDate = orderDate;
}
public Pizza getPizza() {
	return pizza;
}
public void setPizza(Pizza pizza) {
	this.pizza = pizza;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((orderDate == null) ? 0 : orderDate.hashCode());
	result = prime * result + orderId;
	result = prime * result + ((orderType == null) ? 0 : orderType.hashCode());
	result = prime * result + ((pizza == null) ? 0 : pizza.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Orders other = (Orders) obj;
	if (orderDate == null) {
		if (other.orderDate != null)
			return false;
	} else if (!orderDate.equals(other.orderDate))
		return false;
	if (orderId != other.orderId)
		return false;
	if (orderType == null) {
		if (other.orderType != null)
			return false;
	} else if (!orderType.equals(other.orderType))
		return false;
	if (pizza == null) {
		if (other.pizza != null)
			return false;
	} else if (!pizza.equals(other.pizza))
		return false;
	return true;
}
@Override
public String toString() {
	return "Orders [orderId=" + orderId + ", orderType=" + orderType + ", orderDate=" + orderDate + ", pizza=" + pizza
			+ "]";
}

}
