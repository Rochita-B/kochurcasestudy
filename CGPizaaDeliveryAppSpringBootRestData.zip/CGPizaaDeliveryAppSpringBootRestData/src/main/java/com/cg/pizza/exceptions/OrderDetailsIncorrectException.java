package com.cg.pizza.exceptions;

public class OrderDetailsIncorrectException extends Exception{

	public OrderDetailsIncorrectException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsIncorrectException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsIncorrectException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsIncorrectException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsIncorrectException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
