package com.cg.pizza.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.pizza.beans.Orders;
import com.cg.pizza.exceptions.OrderDetailsIncorrectException;
import com.cg.pizza.services.PizzaServices;

@Controller
public class PizzaServiceController {
	@Autowired
	PizzaServices pizzaServices;
	
	@RequestMapping(value= {"/acceptOrderDetails"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public  ResponseEntity<String> acceptOrderDetails(@ModelAttribute Orders order) throws OrderDetailsIncorrectException{
		order=pizzaServices.acceptOrderDetails(order);
		return new ResponseEntity<>("Order confirmed:- "+order.getOrderId(),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getOrderDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public  ResponseEntity<Orders> getOrderDetails(@RequestParam int orderId) throws OrderDetailsIncorrectException{
		Orders order=pizzaServices.getOrderDetails(orderId);
		return new ResponseEntity<Orders>(order,HttpStatus.OK);
	}
	@RequestMapping(value= {"/getAllOrderDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public  ResponseEntity<List<Orders>>getAllOrderDetails() throws OrderDetailsIncorrectException{
		List<Orders> order=pizzaServices.getAllOrderDetails();
		return new ResponseEntity<List<Orders>>(order,HttpStatus.OK);
	}
	@RequestMapping(value= {"/removeOrderDetails"},method=RequestMethod.DELETE,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public  ResponseEntity<String>cancelOrderDetails(@RequestParam int orderId) throws OrderDetailsIncorrectException{
		pizzaServices.cancelOrderDetails(orderId);
		return new ResponseEntity<>("Order  cancelled" ,HttpStatus.OK);
	}
}
