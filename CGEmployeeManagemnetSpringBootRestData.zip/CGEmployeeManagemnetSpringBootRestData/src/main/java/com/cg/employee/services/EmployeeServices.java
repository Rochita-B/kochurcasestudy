package com.cg.employee.services;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;

public interface EmployeeServices {
	Employee getEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException;
	boolean removeEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException;
	List<Employee>getAllEmployeeDetails();
	Employee acceptEmployeeDetails(Employee employee);
}
