package com.cg.employee.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
import com.cg.employee.services.EmployeeServices;

@Controller
public class EmployeeServiceController {
	@Autowired
	EmployeeServices employeeServices;
	
	@RequestMapping(value= {"/getEmployeeDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public  ResponseEntity<Employee> getEmployeeDetails(@RequestParam int empId) throws EmployeeDetailsNotFoundException{
		Employee employee=employeeServices.getEmployeeDetails(empId);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/acceptEmployeeDetails"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public  ResponseEntity<String> acceptEmployeeDetails(@ModelAttribute Employee employee) throws EmployeeDetailsNotFoundException{
		 employee=employeeServices.acceptEmployeeDetails(employee);
		return new ResponseEntity<>("Employee details successfully added:- "+employee.getEmpId(),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getAllEmployeeDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public  ResponseEntity<List<Employee>>getAllEmployeeDetails() throws EmployeeDetailsNotFoundException{
		List<Employee> employee=employeeServices.getAllEmployeeDetails();
		return new ResponseEntity<List<Employee>>(employee,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/removeEmployeeDetails"},method=RequestMethod.DELETE,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public  ResponseEntity<String>removeEmployeeDetails(@RequestParam int empId) throws EmployeeDetailsNotFoundException{
		employeeServices.removeEmployeeDetails(empId);
		return new ResponseEntity<>("Employee details successfully removed" ,HttpStatus.OK);
	}
}
