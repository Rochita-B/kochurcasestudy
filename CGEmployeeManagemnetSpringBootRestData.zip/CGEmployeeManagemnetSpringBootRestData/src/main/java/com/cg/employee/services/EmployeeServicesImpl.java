package com.cg.employee.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.employee.beans.Employee;
import com.cg.employee.daoservices.EmployeeDAO;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;


@Component("employeeServices")
public class EmployeeServicesImpl implements EmployeeServices{
	@Autowired
private EmployeeDAO employeeDAO;
	@Override
	public Employee getEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {	
		return employeeDAO.findById (empId).orElseThrow(()->new EmployeeDetailsNotFoundException("no employee found for this id!"));
	}

	@Override
	public boolean removeEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {
		employeeDAO.delete(getEmployeeDetails(empId));
		return true;
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {		
		return employeeDAO.findAll();
	}

	@Override
	public Employee acceptEmployeeDetails(Employee employee) {	
		return employeeDAO.save(employee);
	}

}
