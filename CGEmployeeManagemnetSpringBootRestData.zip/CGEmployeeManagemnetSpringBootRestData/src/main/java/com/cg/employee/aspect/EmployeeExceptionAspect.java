package com.cg.employee.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
import com.cg.employee.response.CustomerResponse;

@ControllerAdvice
public class EmployeeExceptionAspect {
	@ExceptionHandler(EmployeeDetailsNotFoundException.class)
	public ResponseEntity<CustomerResponse> handelMovieNotFoundException(Exception e) {
		CustomerResponse response=new CustomerResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}
